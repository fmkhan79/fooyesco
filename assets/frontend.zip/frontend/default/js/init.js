"use strict";

// INITIALIZE TOOLTIPS
function initToolTip() {
    $('[data-toggle="tooltip"]').tooltip();
}

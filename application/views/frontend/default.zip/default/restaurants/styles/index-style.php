<!-- order listing carousel -->
<link href="<?php echo base_url('assets/frontend/default/css/owl.theme.default.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/frontend/default/css/owl.carousel.min.css'); ?>" rel="stylesheet">

<style media="screen">
  /* .btn-group1 {
    width: 73%;
  }

  @media (max-width: 576px) {
    .btn-group1 {
      width: 100%;
      border-radius: 3px;
      margin: 0 0 10px;
      padding: 17px;
    }
  } */
  
</style>
<div class="d-flex align-items-center justify-content-between p-4 popup-gray-box">
                    <h3 class="p-0 m-0">Choose one</h3>
                    <div class="op-rq-box"><span>Required</span></div>
                  </div>

                  <div
                    class="d-flex align-items-center p-4 choice-box align-items-center justify-content-between gray-border">
                    <div class="label-box">
                      <label>
                        <input name="chooseone" type="radio" value="med-addons" checked />
                        Medium
                      </label>
                    </div>
                    <div class="amount-box">£10.00</div>
                  </div>

                  <div class="d-flex align-items-center p-4 choice-box align-items-center justify-content-between">
                    <div class="label-box">
                      <label>
                        <input name="chooseone" value="lg-addons" type="radio" />
                        Large
                      </label>
                    </div>
                    <div class="amount-box">£10.00</div>
                  </div>